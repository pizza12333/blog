---
layout: page
title: About
permalink: /about/
feature-img: "assets/img/pexels/circuit.jpeg"
tags: [About, Test]
---

Type on Strap is based on Type Theme, a free and open-source theme for [Jekyll](http://jekyllrb.com/), licensed under the MIT License.

Head over to the [theme's documentation](https://github.io/sylhare/Type-on-Strap) for much more information about Type on Strap or to install this theme on your own Jekyll site.

This file is an example of a page in Jekyll, that automatically shows up in the header navigation, you can delete or modify this file freely.
